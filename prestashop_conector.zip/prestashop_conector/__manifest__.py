{
    'name': 'Integración Odoo-PrestaShop',
    'version': '16.0.0',
    'author': 'Tu Nombre',
    'category': 'Integration',
    'summary': 'Sincroniza productos y recibe pedidos desde PrestaShop.',
    'depends': ['base', 'sale', 'product', 'mail'],
    'data': [  
          'views/prestashop_config_view.xml',
          'security/ir.model.access.csv',
],
    'installable': True,
    'application': False,
}

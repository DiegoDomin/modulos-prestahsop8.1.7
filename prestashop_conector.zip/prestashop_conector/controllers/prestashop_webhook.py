from odoo.http import Controller, route, request

class PrestashopOrderWebhook(Controller):
    @route('/prestashop/order', type='json', auth='public', csrf=False)
    def receive_order(self, **post):
        data = request.jsonrequest
        order_id = data.get('id_order')
        total = data.get('total_paid')
        customer_name = data.get('customer_name')

        # Crear una notificación en Odoo
        request.env['mail.message'].create({
            'message_type': 'notification',
            'body': f'Nuevo pedido recibido: {order_id} - Total: ${total} - Cliente: {customer_name}',
            'res_id': None,
            'model': 'sale.order',
        })

        return {'status': 'success'}

from odoo import models, api, fields
import requests
import logging
import base64
from xml.etree.ElementTree import Element, SubElement, tostring, fromstring

_logger = logging.getLogger(__name__)

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    prestashop_id = fields.Integer(string="PrestaShop ID", help="ID del producto en PrestaShop")

    def _build_product_xml(self, product):
        """Convierte los datos del producto en formato XML esperado por PrestaShop."""
        prestashop_elem = Element('prestashop', attrib={"xmlns:xlink": "http://www.w3.org/1999/xlink"})
        product_elem = SubElement(prestashop_elem, 'product')

        # ID del fabricante y proveedor (pueden ajustarse según las necesidades)
        SubElement(product_elem, 'id_manufacturer').text = '1'
        SubElement(product_elem, 'id_supplier').text = '1'

        # ID de categoría predeterminada
        SubElement(product_elem, 'id_category_default').text = '1'

        # Estado y tipo de producto
        SubElement(product_elem, 'new').text = '1'
        SubElement(product_elem, 'id_default_combination').text = '1'
        SubElement(product_elem, 'id_tax_rules_group').text = '1'
        SubElement(product_elem, 'type').text = '1'
        SubElement(product_elem, 'id_shop_default').text = '1'
        SubElement(product_elem, 'state').text = '1'
        SubElement(product_elem, 'product_type').text = 'standard'

        # Precios
        SubElement(product_elem, 'price').text = f"{product.list_price:.6f}"
        SubElement(product_elem, 'wholesale_price').text = f"{product.standard_price:.6f}"

        # Estado Activo/Inactivo
        SubElement(product_elem, 'active').text = '1' if product.active else '0'
        SubElement(product_elem, 'available_for_order').text = '1'

        # Meta datos y URL amigable
        meta_keywords_elem = SubElement(product_elem, 'meta_keywords')
        SubElement(meta_keywords_elem, 'language', attrib={'id': '2'}).text = 'Keywords'

        link_rewrite_elem = SubElement(product_elem, 'link_rewrite')
        SubElement(link_rewrite_elem, 'language', attrib={'id': '2'}).text = product.name.lower().replace(' ', '-') or "producto-generico"

        # Nombre del producto
        name_elem = SubElement(product_elem, 'name')
        SubElement(name_elem, 'language', attrib={'id': '2'}).text = product.name or "Producto Sin Nombre"

        # Descripciones
        description_elem = SubElement(product_elem, 'description')
        SubElement(description_elem, 'language', attrib={'id': '2'}).text = product.description_sale or ''

        description_short_elem = SubElement(product_elem, 'description_short')
        SubElement(description_short_elem, 'language', attrib={'id': '2'}).text = 'Short description of the product'

        # Asociaciones (categorías)
        associations_elem = SubElement(product_elem, 'associations')
        categories_elem = SubElement(associations_elem, 'categories')
        category_elem = SubElement(categories_elem, 'category')
        SubElement(category_elem, 'id').text = '1'

        return tostring(prestashop_elem, encoding='unicode')

    def sync_to_prestashop(self):
        """Sincroniza el producto actual con PrestaShop."""
        config = self._get_prestashop_config()
        prestashop_url = f"{config.url}/products"
        api_key = config.api_key

        encoded_key = base64.b64encode(f"{api_key}:".encode()).decode()

        headers = {
            'Authorization': f'Basic {encoded_key}',
            'Content-Type': 'application/xml',
            'Accept': 'application/xml'
        }

        for product in self:
            data_xml = self._build_product_xml(product)
            _logger.info("XML Enviado a PrestaShop: %s", data_xml)

            try:
                if product.prestashop_id:
                    response = requests.put(f"{prestashop_url}/{product.prestashop_id}", headers=headers, data=data_xml)
                else:
                    response = requests.post(prestashop_url, headers=headers, data=data_xml)

                _logger.info("PrestaShop Response (%s): %s", response.status_code, response.text)

                if response.status_code == 201:  # Producto creado
                    response_data = fromstring(response.text)
                    product_id = response_data.find('./product/id')
                    if product_id is not None:
                        product.prestashop_id = int(product_id.text)
                elif response.status_code != 200:
                    _logger.error("Error al sincronizar producto: %s", response.text)
            except requests.exceptions.RequestException as e:
                _logger.error("Error de conexión a PrestaShop: %s", str(e))

    def delete_from_prestashop(self):
        """Elimina el producto actual de PrestaShop."""
        config = self._get_prestashop_config()
        prestashop_url = f"{config.url}/products"
        api_key = config.api_key

        encoded_key = base64.b64encode(f"{api_key}:".encode()).decode()

        headers = {'Authorization': f'Basic {encoded_key}'}

        for product in self:
            if product.prestashop_id:
                try:
                    response = requests.delete(f"{prestashop_url}/{product.prestashop_id}", headers=headers)
                    if response.status_code != 200:
                        _logger.error("Error al eliminar producto en PrestaShop: %s", response.text)
                except Exception as e:
                    _logger.error("Error al conectar con PrestaShop: %s", str(e))

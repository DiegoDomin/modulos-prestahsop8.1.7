from odoo import models, fields, api
import base64
import requests

class PrestashopConfig(models.Model):
    _name = 'prestashop.config'
    _description = 'Configuración de PrestaShop'

    url = fields.Char(string='URL de PrestaShop', required=True)
    api_key = fields.Char(string='API Key de PrestaShop', required=True)
    connection_status = fields.Char(string='Estado de Conexión', readonly=True)

    def test_connection(self):
        for record in self:
            try:
                # Codificar la clave API en formato Base64
                api_key_encoded = base64.b64encode(f"{record.api_key}:".encode()).decode()
                headers = {
                    'Authorization': f'Basic {api_key_encoded}',
                }

                # Realizar la solicitud a la API
                response = requests.get(record.url, headers=headers)

                # Validar la respuesta
                if response.status_code == 200:
                    record.connection_status = "Conexión exitosa"
                elif response.status_code == 401:
                    record.connection_status = "Error: Clave de autenticación inválida"
                else:
                    record.connection_status = f"Error: {response.status_code} - {response.text}"
            except Exception as e:
                record.connection_status = f"Error de conexión: {str(e)}"

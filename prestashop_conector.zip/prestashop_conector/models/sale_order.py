import requests
from odoo import models, fields


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    prestashop_order_id = fields.Integer(string="PrestaShop Order ID")

    def _get_prestashop_config(self):
        """Obtiene la configuración de PrestaShop desde el modelo prestashop.config."""
        config = self.env['prestashop.config'].search([], limit=1)
        if not config:
            raise ValueError("No se encontró configuración de PrestaShop. Configúrela en el menú de PrestaShop Configuración.")
        return config

    def fetch_prestashop_orders(self):
        config = self._get_prestashop_config()
        prestashop_url = f"{config.url}/orders"
        api_key = config.api_key

        headers = {'Authorization': f'Basic {api_key}'}

        response = requests.get(prestashop_url, headers=headers)
        if response.status_code == 200:
            orders = response.json().get('orders', [])
            for order in orders:
                if not self.search([('prestashop_order_id', '=', order['id'])]):
                    self.create({
                        'prestashop_order_id': order['id'],
                        'amount_total': order['total_paid'],
                        'partner_id': self.env['res.partner'].search([('email', '=', order['customer_email'])], limit=1).id,
                    })

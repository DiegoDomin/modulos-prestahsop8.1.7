<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class PsCashOnDeliveryChange extends Module
{
    public function __construct()
    {
        $this->name = 'pscashondeliverychange';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->author = 'Tu Nombre';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Pago Contra Reembolso con Cambio');
        $this->description = $this->l('Permite calcular el cambio al usar el método de pago contra reembolso.');
        $this->ps_versions_compliancy = ['min' => '1.7.0.0', 'max' => _PS_VERSION_];
    }

    public function install()
    {
        return parent::install() &&
            $this->registerHook('displayPaymentTop') &&
            $this->registerHook('displayHeader');
    }

    public function uninstall()
    {
        return parent::uninstall();
    }

    public function hookDisplayHeader()
    {
        if ($this->context->controller->php_self === 'order') {
            $this->context->controller->registerStylesheet(
                'module-pscashondeliverychange-style',
                'modules/' . $this->name . '/views/css/cashondelivery.css'
            );
            $this->context->controller->registerJavascript(
                'module-pscashondeliverychange-script',
                'modules/' . $this->name . '/views/js/cashondelivery.js',
                ['position' => 'bottom', 'priority' => 150]
            );
        }
    }

    public function hookDisplayPaymentTop()
    {
        if ($this->isCashOnDeliverySelected()) {
            $this->context->smarty->assign([
                'order_total' => $this->context->cart->getOrderTotal(true, Cart::BOTH),
            ]);

            return $this->display(__FILE__, 'views/templates/front/cashondelivery.tpl');
        }

        return '';
    }

    private function isCashOnDeliverySelected()
    {
        // Comprueba si el método de pago seleccionado es "Pago contra reembolso"
        $paymentOption = Tools::getValue('payment-option');
        return $paymentOption === 'cashondelivery';
    }
}
document.addEventListener('DOMContentLoaded', function () {
    const cashGivenInput = document.getElementById('cash-given');
    const cashChangeDisplay = document.getElementById('cash-change');

    if (cashGivenInput) {
        cashGivenInput.addEventListener('input', function () {
            const total = parseFloat(cashGivenInput.dataset.orderTotal);
            const cashGiven = parseFloat(cashGivenInput.value) || 0;
            const change = (cashGiven - total).toFixed(2);

            cashChangeDisplay.textContent = `$${change > 0 ? change : 0}`;
        });
    }
});

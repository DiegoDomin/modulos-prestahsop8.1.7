<?php

use PrestaShop\PrestaShop\Core\Form\IdentifiableObject\DataProvider\CustomerAddressFormDataProvider;

class CustomerAddressForm extends CustomerAddressFormDataProvider
{
    public function getFormData($id = null)
    {
        $formData = parent::getFormData($id);

        // Personaliza el formulario para incluir el prefijo del país de forma dinámica
        if (!isset($formData['phone_country_code'])) {
            $formData['phone_country_code'] = '+34'; // Valor predeterminado
        }

        return $formData;
    }

    public function getFormFields()
    {
        $fields = parent::getFormFields();
    
        // Lista de códigos de país
        $countryCodes = [
            '+34' => '🇪🇸 España',
            '+1' => '🇺🇸 Estados Unidos',
            '+44' => '🇬🇧 Reino Unido',
            '+33' => '🇫🇷 Francia',
            '+49' => '🇩🇪 Alemania',
            '+91' => '🇮🇳 India',
        ];
    
        // Agrega un campo "select" para el código del país
        $fields['phone_country_code'] = [
            'type' => 'select',
            'label' => $this->translator->trans('Código de País', [], 'Modules.CustomPhonePrefix'),
            'name' => 'phone_country_code',
            'required' => true,
            'options' => [
                'query' => array_map(function ($code, $name) {
                    return ['id' => $code, 'name' => $name];
                }, array_keys($countryCodes), $countryCodes),
                'id' => 'id',
                'name' => 'name',
            ],
        ];
    
        // Modifica el campo del teléfono para que no incluya un prefijo
        if (isset($fields['phone'])) {
            $fields['phone']['type'] = 'text';
            $fields['phone']['desc'] = $this->translator->trans('Por favor, ingrese su número de teléfono sin el código del país.', [], 'Modules.CustomPhonePrefix');
        }
    
        return $fields;
    }
    
}

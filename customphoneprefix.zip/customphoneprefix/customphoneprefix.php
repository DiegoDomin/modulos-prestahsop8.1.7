<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class CustomPhonePrefix extends Module
{
    public function __construct()
    {
        $this->name = 'customphoneprefix';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Tu Nombre';
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('Custom Phone Prefix');
        $this->description = $this->l('Add country code to the phone field in the address form.');
    }

    public function install()
    {
        return parent::install() && 
        $this->registerHook('header');
    }

    public function uninstall()
    {
        return parent::uninstall();
    }

    /**
     * Añade el script necesario al formulario de direcciones
     */
    public function hookHeader()
    {
        if ($this->context->controller->php_self === 'address') {
            $this->context->controller->registerJavascript(
                'module-customphoneprefix-script',
                'modules/' . $this->name . '/views/js/customphoneprefix.js',
                ['priority' => 200]
            );
        }
    }
}

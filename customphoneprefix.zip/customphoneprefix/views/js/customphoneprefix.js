document.addEventListener('DOMContentLoaded', function () {
    const phoneInput = document.getElementById('phone');
    const countryCodeSelect = document.getElementById('phone_country_code');

    // Combina el código de país y el número al enviar el formulario
    const addressForm = document.querySelector('form.address-form');
    if (addressForm) {
        addressForm.addEventListener('submit', function () {
            const selectedCode = countryCodeSelect.value.trim();
            if (phoneInput.value && !phoneInput.value.startsWith(selectedCode)) {
                phoneInput.value = `${selectedCode} ${phoneInput.value}`;
            }
        });
    }
});

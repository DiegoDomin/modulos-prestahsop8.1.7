document.addEventListener("DOMContentLoaded", function () {
    const paymentRadios = document.querySelectorAll('input[name="payment-option"]');
    const cashPaymentSection = document.getElementById("cash-payment-section");
    const cashAmountInput = document.getElementById("cash-amount");
    const changeResult = document.getElementById("change-result");
    const changeAmount = document.getElementById("change-amount");

    if (!cashPaymentSection) return;

    const totalAmount = parseFloat(cashPaymentSection.dataset.total);

    // Mostrar el campo cuando se selecciona "Pago contra reembolso"
    paymentRadios.forEach((radio) => {
        radio.addEventListener("change", function () {
            if (radio.dataset.moduleName === "ps_cashondelivery") {
                cashPaymentSection.style.display = "block";
            } else {
                cashPaymentSection.style.display = "none";
                cashAmountInput.value = "";
                changeResult.style.display = "none";
            }
        });

        // Si el radio ya está seleccionado al cargar la página
        if (radio.checked && radio.dataset.moduleName === "ps_cashondelivery") {
            cashPaymentSection.style.display = "block";
        }
    });

    // Calcular el cambio
    cashAmountInput.addEventListener("input", function () {
        const cashAmount = parseFloat(this.value);

        if (cashAmount >= totalAmount) {
            const change = (cashAmount - totalAmount).toFixed(2); // 2 decimales
            changeAmount.textContent = `$${change}`;
            changeResult.style.display = "block";
        } else {
            changeResult.style.display = "none";
        }
    });
});

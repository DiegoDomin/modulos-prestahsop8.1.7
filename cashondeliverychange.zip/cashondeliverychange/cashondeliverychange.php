<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class CashOnDeliveryChange extends Module
{
    public function __construct()
    {
        $this->name = 'cashondeliverychange';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Diego';
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Cambio para pago contra reembolso');
        $this->description = $this->l('Añade una funcionalidad para calcular el cambio en el método de pago contra reembolso.');
    }

    public function install()
    {
        return parent::install() &&
            $this->registerHook('displayPayment') &&
            $this->registerHook('header');
    }

    public function hookDisplayPayment($params)
    {
        $total = $this->context->cart->getOrderTotal(true, Cart::BOTH);
    
        $this->context->smarty->assign([
            'total' => $total,
        ]);
    
        return $this->display(__FILE__, 'views/templates/hook/displayPayment.tpl');
    }
    

    public function hookHeader($params)
    {
        $this->context->controller->registerJavascript(
            'module-cashondeliverychange',
            'modules/' . $this->name . '/views/js/cashondeliverychange.js',
            [
                'position' => 'bottom',
                'priority' => 150,
            ]
        );
    }
}
